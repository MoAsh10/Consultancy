<?php
require "db.php";

$e = $_POST['email'];
$p = $_POST['password'];

$q = $pdo->prepare("SELECT * FROM users WHERE email=?");
$q->execute([$e]);

$u = $q->fetch(PDO::FETCH_ASSOC);

if ($u && password_verify($p, $u['password'])) {

  echo json_encode([
    "status" => "success",
    "user" => [
      "id" => $u['id'],
      "name" => $u['full_name'],
      "email" => $u['email'],
      "phone" => $u['phone'],
      "role" => $u['role']
    ]
  ]);

}
else {

  echo json_encode([
    "status" => "error",
    "message" => "Invalid email or password"
  ]);

}
