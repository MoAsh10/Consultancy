<?php
require "db.php";

$uid = $_POST['user_id'];

try {

  $q = $pdo->prepare("
    INSERT INTO user_profiles
    (user_id, first_name, last_name, dob, gender, bio,
     prof_role, prof_status, industry, experience,
     company, skills, aspirations, challenges, topics)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      first_name=VALUES(first_name),
      last_name=VALUES(last_name),
      dob=VALUES(dob),
      gender=VALUES(gender),
      bio=VALUES(bio),
      prof_role=VALUES(prof_role),
      prof_status=VALUES(prof_status),
      industry=VALUES(industry),
      experience=VALUES(experience),
      company=VALUES(company),
      skills=VALUES(skills),
      aspirations=VALUES(aspirations),
      challenges=VALUES(challenges),
      topics=VALUES(topics)
  ");

  $q->execute([
    $uid,
    $_POST['firstName'],
    $_POST['lastName'],
    $_POST['dob'],
    $_POST['gender'],
    $_POST['bio'],
    $_POST['currentRole'],
    $_POST['currentStatus'],
    $_POST['industry'],
    $_POST['experience'],
    $_POST['company'],
    $_POST['skills'],
    $_POST['aspirations'],
    $_POST['challenges'],
    $_POST['topics']
  ]);

  echo json_encode(["status"=>"success"]);

} catch(PDOException $e) {
  echo json_encode(["status"=>"error","message"=>$e->getMessage()]);
}
