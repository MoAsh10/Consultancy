<?php
require "db.php";

$uid = $_POST['user_id'];

$q = $pdo->prepare("SELECT * FROM user_profiles WHERE user_id=?");
$q->execute([$uid]);

$p = $q->fetch(PDO::FETCH_ASSOC);

echo json_encode($p ?: []);
