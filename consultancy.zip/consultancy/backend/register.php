<?php
require 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$role = $_POST['role'];
$status = $_POST['status'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

$stmt = $pdo->prepare(
  "INSERT INTO users 
  (full_name, email, password, phone, role, status) 
  VALUES (?, ?, ?, ?, ?, ?)"
);

try {
  $stmt->execute([
    $name,
    $email,
    $password,
    $phone,
    $role,
    $status
  ]);

  echo json_encode(["status" => "success"]);
} catch (PDOException $e) {
  echo json_encode([
    "status" => "error",
    "message" => "Email already registered"
  ]);
}
