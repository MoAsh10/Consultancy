function registerUser() {
  const data = {
    name: $("#name").val(),
    email: $("#email").val(),
    password: $("#password").val(),
    phone: $("#phone").val(),
    role: $("#role").val(),
    status: $("#status").val()
  };

  if (!data.name || !data.email || !data.password || !data.role) {
    $("#msg").text("Please fill all required fields");
    return;
  }

  $.ajax({
    url: "../backend/register.php",
    type: "POST",
    data: data,
    success: function (res) {
      const r = JSON.parse(res);
      if (r.status === "success") {
        alert("Registration successful! Please login.");
        window.location.href = "login.html";
      } else {
        $("#msg").text(r.message);
      }
    }
  });
}

function loginUser() {

  let e = $("#email").val();
  let p = $("#password").val();

  if (e=="" || p=="") {
    $("#msg").text("Please enter email and password");
    return;
  }

  $.ajax({
    url: "../backend/login.php",
    type: "POST",
    data: {
      email: e,
      password: p
    },
    success: function(res) {

      let r = JSON.parse(res);

      if (r.status === "success") {
        localStorage.setItem("user", JSON.stringify(r.user));
        window.location.href = "dashboard.html";

      } else {
        $("#msg").text(r.message);
      }

    }
  });
}
